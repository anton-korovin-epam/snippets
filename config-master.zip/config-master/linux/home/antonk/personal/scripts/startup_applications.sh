#! /bin/bash

pkill xxkb
pkill blueberry-tray

sleep 5s

setxkbmap "us,ru" ",winkeys" "grp:shift_caps_toggle" &
i3-sensible-terminal &
nitrogen --restore &
xxkb &
sudo nm-applet &
blueberry-tray &


$HOME/bin/autostart.sh
