#! /bin/bash

IMAGE_DIR=/home/antonk/images/wallpapers/
#IMAGE_DIR=/usr/share/wallpapers


IMAGE=`find ${IMAGE_DIR} -name '*.png' | grep -v 'screenshot'| shuf | tail -n 1`

echo "Image=${IMAGE}"

COLOR=000000

# i3lock -i $IMAGE -t
# i3lock --color=$COLOR

# /home/antonk/.i3/i3lock-multimonitor/lock -i ${IMAGE}

#/home/antonk/dev/my/util/i3/i3lock-multimonitor/lock -i ${IMAGE} -a '-f -k --ignore-empty-password'



i3lock \
  --show-failed-attempts \
  --ignore-empty-password \
  --image=${IMAGE} \
  --tiling \
  --color=${COLOR} &>/tmp/i3-lock.log
