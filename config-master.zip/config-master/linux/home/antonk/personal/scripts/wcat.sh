#! /bin/bash

cat `which ${1}`
