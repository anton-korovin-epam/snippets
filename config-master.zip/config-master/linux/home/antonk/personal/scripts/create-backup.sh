SRC=$1
DST=$2

B=`basename $SRC`

D=`date +'%Y-%m-%d'`
T=`date +'%H-%M-%S'`

DST_DIR=${DST}/${D}
DST_FILE=${DST_DIR}/${D}-${T}-${B}.tar.gz

mkdir -p ${DST}/${D} && \
  tar zcf ${DST_FILE} ${SRC}

r=$?
NOTIF=""
if [[ "$r" == "0" ]];then
  NOTIF="display notification \"Backup created: $B\""
else
  NOTIF="display notification \"Backup creation failed: [$B]. Code: $r\""
fi

osascript -e "${NOTIF}"

