#! /bin/bash

# https://askubuntu.com/questions/62166/siocsifflags-operation-not-possible-due-to-rf-kill
sudo rfkill unblock wifi
