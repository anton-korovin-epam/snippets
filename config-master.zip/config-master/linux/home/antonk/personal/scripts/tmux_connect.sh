#! /bin/bash

SESSION_NAME=$1

echo "$SESSION_NAME"

if [ "$SESSION_NAME" == "" ]
 then
  echo "Usage: $0 <session_name>"
  exit -1
 fi


SCRIPTS_DIR="/home/antonk/personal/scripts/tmux"

FOUND_SESSION=`tmux list-sessions -F '#{session_name}' | grep '^'$SESSION_NAME'$'`


# tmux has-session -t "$SESSION_NAME" &> /dev/null



if [ "$FOUND_SESSION" != "$SESSION_NAME" ]
then
    tmux new-session -s "$SESSION_NAME" -n "$SESSION_NAME" -d
    tmux send-keys -t "$SESSION_NAME" "$SCRIPTS_DIR/$SESSION_NAME" C-m
    echo "Create"
else
    echo "Attach"
fi

tmux attach -t "$SESSION_NAME"
