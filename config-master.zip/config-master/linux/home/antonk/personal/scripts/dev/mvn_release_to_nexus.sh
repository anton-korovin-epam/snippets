
mvn -nsu  -fn  deploy -DaltDeploymentRepository=OPOS-Releases::default::http://192.168.2.225:3002/content/repositories/OPOS-Releases/ -DskipTests=true
