#! env python
import socket               # Import socket modulefrom time import sleep
from time import sleep

s = socket.socket()         # Create a socket object
host = '127.0.0.1'
port = 9999                 # Reserve a port for your service.

s.connect((host, port))

while (True):
  f = open('dump.bin','rb')
  l = f.read(1024)
  while (l):
    s.send(l)
    l = f.read(1024)
#    sleep(0.01)
  f.close()
s.close
