#! /bin/bash

sudo iw dev wlp3s0 interface add mon0 type monitor
sudo ifconfig wlp3s0 down
sudo ifconfig mon0 up
