#! /bin/bash

DEST_DEV=$HOME/work/today/lingtwins/dev
DEST_DEMO=$HOME/work/today/lingtwins/demo


mkdir -p $DEST_DEMO
mkdir -p $DEST_DEV


scp "altdev@lt_demo:/opt/lingtwins/rest/log/*" $DEST_DEMO

scp "altdev@lt_dev:/opt/lingtwins/rest/log/*" $DEST_DEV
