#!/bin/bash

# This way you can customize which branches should be skipped when
# prepending commit message.
if [ -z "$BRANCHES_TO_SKIP" ]; then
  BRANCHES_TO_SKIP=("^master\$" "development\$" "^test\$" "sprint-[.0-9]+")
fi

BRANCH_NAME=$(git symbolic-ref --short HEAD)
BRANCH_NAME="${BRANCH_NAME##*/}"

BRANCH_EXCLUDED="0"
for ((i=0; i < ${#BRANCHES_TO_SKIP[@]}; ++i)); do
    if [[ "${BRANCH_NAME}" =~ ${BRANCHES_TO_SKIP[$i]} ]]; then
        BRANCH_EXCLUDED="1"
    fi
done

BRANCH_IN_COMMIT=$(grep -c "\[$BRANCH_NAME\]" $1)

if [ -n "$BRANCH_NAME" ] && ! [[ $BRANCH_EXCLUDED -eq 1 ]] && ! [[ $BRANCH_IN_COMMIT -ge 1 ]]; then
  sed -i.bak -e "1s/^/[$BRANCH_NAME] /" $1
fi
