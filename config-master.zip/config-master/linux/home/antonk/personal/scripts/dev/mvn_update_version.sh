 mvn versions:set -DnewVersion="$1"
