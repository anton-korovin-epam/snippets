#! /bin/bash

echo -n $1 | perl -pe 's/([0-9a-f]{2})/chr hex $1/gie'

# echo $1 | python3 -c "import sys, binascii; sys.stdout.buffer.write(binascii.unhexlify(input().strip()))"
