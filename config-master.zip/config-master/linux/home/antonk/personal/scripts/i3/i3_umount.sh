#! /bin/bash

M=`mount | grep "/" | awk 'BEGIN{i=0;}{print i, $3,"|";i=i+1;}'`
echo -e `echo $M | tr '|' '\\n'`
