#! /bin/bash

OLD_LANG=$LANG
export LANG="en"

TODAY=`date +'%Y/%m_%b/%d'`

SKYPE=$HOME"/downloads/skype"
DOWNLOADS=$HOME"/downloads/browser"
STUFF_NT_SCREEN=$HOME"/downloads/stuff/nt/screen"
WORK=$HOME/"work"

TODAY_DIR_NAME="today"

create_today_dir()
{
    BASE_DIR=$1
    TODAY_DIR=$BASE_DIR"/$TODAY"
    TODAY_LINK=$BASE_DIR"/$TODAY_DIR_NAME"

    OLD_DIR=`readlink -f $TODAY_LINK`
    if [[ -d $OLD_DIR ]];
    then
        rmdir $OLD_DIR &>/dev/null
    fi

    if [[ ! -d $TODAY_DIR ]];
    then
        mkdir -p $TODAY_DIR
        rm $TODAY_LINK
        ln -s $TODAY_DIR $TODAY_LINK
    fi
}


#!/bin/bash

readonly PROGNAME=$(basename "$0")
readonly LOCKFILE_DIR=/tmp
readonly LOCK_FD=200

lock() {
    local prefix=$1
    local fd=${2:-$LOCK_FD}
    local lock_file=$LOCKFILE_DIR/$prefix.lock

    # create lock file
    eval "exec $fd>$lock_file"

    # acquier the lock
    flock -n $fd \
        && return 0 \
        || return 1
}

eexit() {
    local error_str="$@"

    echo $error_str
    exit 1
}

main() {
    lock $PROGNAME \
        || eexit "Only one instance of $PROGNAME can run at one time."

#    create_today_dir $SKYPE
    create_today_dir $DOWNLOADS
    create_today_dir $WORK
#    create_today_dir $STUFF_NT_SCREEN

    export LANG=$OLD_LANG
}



main
