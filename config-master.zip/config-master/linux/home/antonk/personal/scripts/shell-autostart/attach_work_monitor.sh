#!/bin/bash

MODE=1920x1080
ARRANGEMENT=--right-of


if [[ "2" -eq "`xrandr | grep -c \" connected \"`" ]];
then
   VGA=`xrandr  | grep " connected" | grep -E "VGA|HDMI" | awk  '{print $1;}'`
   LVDS=`xrandr | grep " connected" | grep LVDS | awk  '{print $1;}'`

   xrandr --output $VGA --mode $MODE $ARRANGEMENT $LVDS
   xrandr --output $LVDS --mode "1600x900"
else
   xrandr --auto
fi
