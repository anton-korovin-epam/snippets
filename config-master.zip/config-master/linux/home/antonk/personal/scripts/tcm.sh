#! /bin/bash

TMUX_SCRIPTS="/home/antonk/personal/scripts/tmux"

DIALOG=${DIALOG=dialog}

tempfile=`mktemp 2>/dev/null` || tempfile=/tmp/tcm$$
trap "rm -f $tempfile" 0 1 2 5 15


MENU_ITEMS=""

for ts in `ls -1 $TMUX_SCRIPTS`;
do
  if [[ -x ${TMUX_SCRIPTS}/${ts} ]];
  then
    tmux list-sessions -F '#{session_name}' | grep "^${ts}\$"
    EXIST="$?"
    TS_INDEX=""
    if [[ $EXIST == "0" ]];
    then
        TS_INDEX="+"
    else
        TS_INDEX="------"
    fi

    echo "$TS_INDEX $EXIST"

    MENU_ITEMS="$MENU_ITEMS $ts $TS_INDEX "
  else
    echo "Skip '${ts}'"
  fi
done

# exit 0

$DIALOG --clear --title "Tmux sessions" \
        --menu "" 18 50 12 \
        ${MENU_ITEMS} \
        2> $tempfile


retval=$?

choice=`cat $tempfile`

case $retval in
  0)
   tmux_connect.sh "$choice"
   ;;
  *)
   clear
   ;;
esac
