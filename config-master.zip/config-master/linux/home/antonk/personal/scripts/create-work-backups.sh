r=`osascript -e 'display dialog "Create ?" buttons {"No", "Yes"}' | awk -F ':' '{print $2}'`

S="/Users/anton_korovin/personal/config/linux/home/antonk/personal/scripts"
CB=${S}/create-backup.sh

LSEG=/Users/anton_korovin/OneDrive/lseg-drive/Backup
EPAM=/Users/anton_korovin/OneDrive/epam-drive/Backup

if [[ "$r" == "Yes" ]]; then
    ${CB} ${HOME}/dev ${LSEG}
    ${CB} ${HOME}/personal ${EPAM}
    ${CB} ${HOME}/bin ${EPAM}
    ${CB} ${HOME}/Tools ${EPAM}
    ${CB} ${HOME}/research ${EPAM}
fi

