#! /bin/bash

find $HOME/personal/scripts/shell-autostart -name "*.sh" -exec {} ';'

pkill xxkb
xxkb &>/dev/null &

blueman-applet &>/dev/null &
