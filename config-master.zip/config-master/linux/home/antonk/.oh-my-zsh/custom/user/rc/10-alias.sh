# ################################################
#                  ALIASES
# ################################################

# alias ls='ls --color=auto'
alias ls='eza'
alias grep='grep --colour=auto'
alias cls='clear'
# alias ping="/home/antonk/dev_tools/cli/prettyping"
alias ssh="TERM=screen ssh"
alias lsblk="lsblk -o 'NAME,MAJ:MIN,RM,LABEL,SIZE,RO,TYPE,MOUNTPOINT'"

alias golang="/usr/local/bin/go"

# git aliases
alias gst='git status '
alias gss='git ss'
alias ga='git add '
alias gam='git add-modified'
alias gb='git branch '
alias gc='git commit'
alias gcm='git commit -m'
alias gd='git diff'
alias gds='git diff --staged'
alias go='git checkout'
alias gom='git checkout `git-main-branch`'
alias gg='git gui'
alias gh='git hist'
# alias ghs='git sh'
alias gl='git last'
alias gt='git show-tree'
alias gdt='git difftool -y'
alias glc='git list-commits-no-merges'
alias glcm='git list-commits'


# tmux aliases
alias tmux="TERM=screen-256color tmux"
alias tn='tmux new'
alias ta='tmux attach -t'
alias td='tmux detach'
alias tls='tmux list-sessions'
alias tlw='tmux list-windows'
alias tks='tmux kill-session -t'

alias mux=tmuxinator

# color aliases
# alias gcc='/usr/bin/colorgcc'
# alias g++='/usr/bin/colorgcc'
# alias cc='/usr/bin/colorgcc'

AMM_COURSIER_REPOSITORIES="ivy2Local|central|sonatype:releases|jitpack"

alias amm='JAVA_OPTS="" COURSIER_REPOSITORIES=${AMM_COURSIER_REPOSITORIES} /usr/local/bin/amm'


# Fix autocorrection
# https://superuser.com/questions/439209/how-to-partially-disable-the-zshs-autocorrect
# alias vim='nocorrect vim'

#alias code='/Applications/Visual\ Studio\ Code.app/Contents/MacOS/Electron'

alias code-zsh="code ${ZSH_CUSTOM}"
alias vim='nvim'
alias nvim-config="nvim $HOME/.config/nvim/init.vim"
alias sudo='nocorrect sudo'

#alias python=python3
#alias pip=pip3

# ################################################

body() {
    IFS= read -r header
    printf '%s\n' "$header"
    "$@"
}

alias df="df -hPT | column -t | body sort -rhk 6"
alias ll="ls -lah"
# alias rm="rm -i"
alias cp="cp -i"
alias l="ls -ail"
alias cl="clear"
alias i7z="sudo i7z"
alias iotop="sudo iotop"

# OMZ shorts
alias ql="os-quick-look"

alias reboot="shutdown -r now"
alias kill9="kill -9"
# do a du -hs on each dir on current path
alias lsdir="for dir in *;do;if [ -d \$dir ];then;du -hs \$dir;fi;done"

# alias laws="aws --endpoint-url=$LOCALSTACK_ENDPOINT_URL"

alias edit-config-tmux='vim ~/.tmux.conf'

# alias mc="EDITOR='vim' TERM=xterm-color mc"
# alias mcedit='TERM=xterm-color mcedit -u'

# ################################################

alias pio=platformio
