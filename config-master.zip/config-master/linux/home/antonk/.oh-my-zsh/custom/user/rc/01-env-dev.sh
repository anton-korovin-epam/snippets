export ITOP_HTTP__DEV_LOG_FORMAT=1
export ITOP_RT_EXTRACTOR__DEV_LOG_FORMAT=1
export DEV_LOG_FORMAT=1

export MY_DEV=${HOME}/dev
export ITOP_DIAGNOSTIC_TOOL=${HOME}/dev/itop-diagnostic-tool

export MY_PYTHON=${HOME}/.pyenv/shims/python

# K8S
export KUBECONFIG_QA=$HOME/.kube/config-aws-qa
export KUBECONFIG_DEV=$HOME/.kube/config-aws-dev
export KUBECONFIG_DEV_PPE=$HOME/.kube/config-aws-dev-ppe
export KUBECONFIG_DEV_PERF=$HOME/.kube/config-aws-dev-perf
export KUBECONFIG_PERF=$HOME/.kube/config-aws-perf
export KUBECONFIG_PPE=$HOME/.kube/config-aws-ppe
export KUBECONFIG_PROD=$HOME/.kube/config-aws-prod
export KUBECONFIG_DR=$HOME/.kube/config-aws-dr

export KUBECONFIG_PROD_WRITABLE=$HOME/.kube/config-aws-prod-writable
export KUBECONFIG_DR_WRITABLE=$HOME/.kube/config-aws-dr-writable

# PPE
export ITOP_AWS_PPE_USER='aux505463@qarft.refinitiv.com'
export ITOP_AWS_PPE_ACCOUNT='edp-intel-sdlc-preprod'
export ITOP_AWS_PPE_ROLE='human-role/a205917-Developer'
export ITOP_AWS_PPE_PROFILE='itop-preprod'
export ITOP_AWS_PPE_REGION='eu-west-1'

export ITOP_AWS_PPE_EKS_QA='a205917-kve-qa-preprod-eks'
export ITOP_AWS_PPE_EKS_PERF='a205917-kve-perftest-preprod-eks'
export ITOP_AWS_PPE_EKS_PPE='a205917-kve-ppe-preprod-eks'
export ITOP_AWS_PPE_EKS_DEV='a205917-kve-dev-preprod-eks'

# DEV
export ITOP_AWS_DEV_USER='aux505463@dvrft.refinitiv.com'
export ITOP_AWS_DEV_ACCOUNT='aws-4-dev-test-itop'
export ITOP_AWS_DEV_ROLE='human-role/a205917-Developer'
export ITOP_AWS_DEV_PROFILE='itop-dev'
export ITOP_AWS_DEV_REGION='eu-west-1'

# DEV-PERF
export ITOP_AWS_DEV_PERF_PROFILE='itop-dev-perf'
export ITOP_AWS_DEV_PERF_REGION='eu-west-1'

# DEV-PPE
export ITOP_AWS_DEV_PPE_PROFILE='itop-dev-ppe'
export ITOP_AWS_DEV_PPE_REGION='eu-west-1'


# PROD
export ITOP_AWS_PROD_USER='aux505463@prrft.refinitiv.com'
export ITOP_AWS_PROD_ACCOUNT='edp-intel-sdlc-prod'
export ITOP_AWS_PROD_ROLE='human-role/205917-ReadOnly'
export ITOP_AWS_PROD_PROFILE='itop-prod-ro'
export ITOP_AWS_PROD_REGION='eu-west-1'
export ITOP_AWS_PROD_EKS='a205917-kve-eap-prod-eks'

export ITOP_AWS_PROD_WRITABLE_ROLE='human-role/a205917-Developer'
export ITOP_AWS_PROD_WRITABLE_PROFILE='itop-prod-writable'
export ITOP_AWS_DR_WRITABLE_PROFILE='itop-dr-writable'


# DR
export ITOP_AWS_DR_USER='aux505463@prrft.refinitiv.com'
export ITOP_AWS_DR_ACCOUNT='edp-intel-sdlc-prod'
export ITOP_AWS_DR_ROLE='human-role/205917-ReadOnly'
export ITOP_AWS_DR_REGION='us-east-1'
export ITOP_AWS_DR_EKS='a205917-kve-dr-prod-eks'



export MY_PROJECTS="api-info-service
calais-extractor
generic-extractor-proxy
EIT-Summarization
iTOP-backfeed-brief-engine
itop-charts
iTOP-enrichment-conversion-service
iTOP-feedback-loop-extractor
iTOP-fundamentals-extractor
iTOP-http-gateway
iTOP-java-platform-common
itop-pipelines
itop-local-simulation
iTOP-merger-extractor
iTOP-monitoring-tool
iTOP-scala-platform-common
iTop-textract-lambdas
iTOP-translation-service
itop-upstream-callback-lambdas
iTOP-wrapper-adapter
key-value
rt-extractor
sourcing-engine
"

export MY_RELEASING_PROJECTS="generic-extractor-proxy
rt-extractor
calais-extractor
iTOP-enrichment-conversion-service
iTOP-feedback-loop-extractor
iTOP-http-gateway
iTOP-monitoring-tool
iTOP-wrapper-adapter
iTop-textract-lambdas
"

export MY_CURR_RELEASE="24-02-3.1.11"
export MY_PREV_RELEASE="23-11-3.1.10"

export MY_RELEASE_DIR=${MY_DEV}/releases
# export MY_PREV_RELEASE_BRANCH="release-july-22"
export MY_CURR_RELEASE_BRANCH="release-24-feb-3.1.11"


export MY_CURR_RELEASE_DIR="${MY_RELEASE_DIR}/${MY_CURR_RELEASE}"

# ITOP Simulation
export ITOP_SIM_QUEUES_RT="rt-request-ready rt-external-request refinement-done"
export ITOP_SIM_QUEUES_MT="mt-input"
export ITOP_SIM_QUEUES_GE="ge-test-input"
export ITOP_SIM_QUEUES_CS="cs-ees-input cs-ees-v2-input cs-fcs-input textract"
export ITOP_SIM_QUEUES_RRT="rrt-company-input rrt-section-marker-input rrt-report-type-input rrt-reason-input rrt-country-input rrt-industry-input rrt-merger-input" 
export ITOP_SIM_QUEUES_TRIT="calais-extractor-input"
export ITOP_SIM_QUEUES_SUMM="summarization-input backfeed-brief-input"

export ITOP_SIM_QUEUES="${ITOP_SIM_QUEUES_RT} ${ITOP_SIM_QUEUES_MT} ${ITOP_SIM_QUEUES_GE} ${ITOP_SIM_QUEUES_TRIT} ${ITOP_SIM_QUEUES_CS} ${ITOP_SIM_QUEUES_RRT} ${ITOP_SIM_QUEUES_SUMM}"

export ITOP_SIM_BUCKETS="itop-external-bucket itop-internal-bucket itop-wrapper"
