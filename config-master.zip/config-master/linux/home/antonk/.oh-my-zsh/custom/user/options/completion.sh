# case-insensitive (uppercase from lowercase) completion
#zstyle ':completion:*' matcher-list 'm:{a-z}={A-Z}'

# process completion
#zstyle ':completion:*:processes' command 'ps -au$USER'
#zstyle ':completion:*:*:kill:*:processes' list-colors "=(#b) #([0-9]#)*=36=31"

# zstyle
#zstyle ':completion:*' completer _expand _complete _ignored
#zstyle ':completion:*' list-colors ${(s.:.)LS_COLORS}
#zstyle ':completion:*' menu select=2
#zstyle ':completion:*' select-prompt '%SScrolling active: current selection at %p%s'
#zstyle ':completion:*:descriptions' format '%U%F{yellow}%d%f%u'


#autoload -Uz compinit
#compinit

# AWS
autoload bashcompinit && bashcompinit

source /usr/local/bin/aws_zsh_completer.sh

# For localstack
complete -C '/usr/local/bin/aws_completer' laws

# For itop-ppe
complete -C '/usr/local/bin/aws_completer' qaws

# For itop-dev
complete -C '/usr/local/bin/aws_completer' daws

# For itop-dev-perf
complete -C '/usr/local/bin/aws_completer' daws-perf

# For itop-dev-ppe
complete -C '/usr/local/bin/aws_completer' daws-ppe

# For itop-prod
complete -C '/usr/local/bin/aws_completer' prod-aws
complete -C '/usr/local/bin/aws_completer' prod-writable-aws
