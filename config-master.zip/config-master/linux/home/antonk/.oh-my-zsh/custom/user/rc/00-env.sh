export MY_DOCS=$HOME/Documents
export MY_WORK=$HOME/work
export MY_WORK_TODAY=${MY_WORK}/today
export MY_TASKS=$MY_WORK/tasks
export MY_DOWNLOADS=$HOME/Downloads

export MY_PERSONAL=${HOME}/personal

export MY_TMUX_SESSIONS=${MY_PERSONAL}/env/tmux
export MY_TMUX_MENU_SCRIPTS=${MY_PERSONAL}/scripts/tmux/menu-scripts
export MY_TMUX_LAUNCHER_SCRIPTS=${MY_PERSONAL}/scripts/tmux/launcher-scripts


export ITOP_AWS_PPE_PASS=""

export MY_RUNTIME_PATH=${MY_PERSONAL}/config/macos/Users/anton_korovin/personal/runtime/

export MY_EDITOR="nvim"

export HOMEBREW_NO_AUTO_UPDATE="1"

# pyenv works by inserting a directory of shims at the front of your PATH:
PATH=$(pyenv root)/shims:$PATH

PATH=$PATH:$HOME/bin:
PATH=$PATH:/Applications/Cisco/p4merge.app/Contents/MacOS
PATH=$PATH:/Applications/Meld.app/Contents/MacOS/
PATH=$PATH:/Applications/DiffMerge.app/Contents/MacOS
PATH=$PATH:"/usr/local/opt/node@14/bin"
PATH=$PATH:$HOME/.platformio/penv/bin


PATH=$PATH:${MY_PERSONAL}/scripts
PATH=$PATH:${MY_PERSONAL}/scripts/git
PATH=$PATH:${MY_PERSONAL}/scripts/tmux
PATH=$PATH:${MY_PERSONAL}/scripts/shell
PATH=$PATH:${MY_PERSONAL}/scripts/itop
PATH=$PATH:${MY_PERSONAL}/scripts/laws
PATH=$PATH:${MY_PERSONAL}/scripts/qaws
PATH=$PATH:${MY_PERSONAL}/scripts/itop-preprod-aws
PATH=$PATH:${MY_TMUX_MENU_SCRIPTS}
PATH=$PATH:${MY_TMUX_LAUNCHER_SCRIPTS}

export PATH

export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-11.0.14.jdk/Contents/Home

LOCALSTACK_ENDPOINT_URL="http://localhost:4566"

export EDITOR=${MY_EDITOR}
export KUBE_EDITOR=${MY_EDITOR}


export NVM_DIR="$HOME/.nvm"
[ -s "/usr/local/opt/nvm/nvm.sh" ] && \. "/usr/local/opt/nvm/nvm.sh"  # This loads nvm
[ -s "/usr/local/opt/nvm/etc/bash_completion.d/nvm" ] && \. "/usr/local/opt/nvm/etc/bash_completion.d/nvm"  # This loads nvm bash_completion


# Colors

export C_NC='\e[0m' # No Color
export C_BLACK='\e[0;30m'
export C_GRAY='\e[1;30m'
export C_RED='\e[0;31m'
export C_LIGHT_RED='\e[1;31m'
export C_GREEN='\e[0;32m'
export C_LIGHT_GREEN='\e[1;32m'
export C_BROWN='\e[0;33m'
export C_YELLOW='\e[1;33m'
export C_BLUE='\e[0;34m'
export C_LIGHT_BLUE='\e[1;34m'
export C_PURPLE='\e[0;35m'
export C_LIGHT_PURPLE='\e[1;35m'
export C_CYAN='\e[0;36m'
export C_LIGHT_CYAN='\e[1;36m'
export C_LIGHT_GRAY='\e[0;37m'
export C_WHITE='\e[1;37m'
