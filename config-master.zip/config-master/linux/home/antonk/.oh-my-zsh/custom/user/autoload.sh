U=$ZSH_CUSTOM/user

# Resource files (environment, functions, aliases)
for file in `ls -1 ${U}/rc/*.sh | sort`; do
    source $file
done

# Shell options
for file in ${U}/options/*.sh; do
    source $file
done

# Autostart
for file in `find ${U}/autostart/ -type f -name '*.sh'`; do
    $file
done
