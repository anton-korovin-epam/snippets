# BAMS
export BAMS_PSWD=$(cat $MY_RUNTIME_PATH/.bams-pass)
export BAMS_USER=anton.korovin
