Personal config and scripts
---------

Useful cli tools

|Tool|Description|Link|
|---|---|---|
||||
|ammonite-repl|||
|bat|A cat clone with wings|[Repo](https://github.com/sharkdp/bat)|
|btop|||
|ctop|||
|delta|A syntax-highlighting pager for git, diff, and grep output|[Repo](https://github.com/dandavison/delta)|
|dialog|||
|docker|||
|eza|eza is a modern, maintained replacement for the venerable file-listing command-line program ls|[Repo](https://github.com/eza-community/eza)|
|fd|||
|ffmpeg|||
|fzf|||
|gitg|||
|gitu|A terminal user interface for Git. Inspired by Magit.|[Repo](https://github.com/altsem/gitu)|
|graphviz|||
|helm|||
|htop|||
|jq|||
|k9s|||
|klg|Viewing logs of Kubernetes pods using lnav.|[Repo](https://github.com/haphamdev/klg)|
|kubernetes-cli|||
|lnav|||
|minicube|||
|moar|moar - the nice pager (less)||
|mpc/mpd|||
|mupdf|||
|ncdu|||
|ncmpcpp|||
|neovim|||
|pandoc|||
|s3cmd|||
|ripgrep|ripgrep is a line-oriented search tool that recursively searches the current directory for a regex pattern.|[Repo](https://github.com/BurntSushi/ripgrep/)|
|tig|text-mode interface for Git|[Repo](https://github.com/jonas/tig/)|
|tmux|||
|tmux-fzf|||
|tmuxinator|||
|vifm|||


MacOS apps
-----------
|Tool|Description|Link|
|---|---|---|
|DBeaver|DB client||
|iTerm|||
|p4merge|||
|rectangle|||
|translatium|||
|Amphetamine|||
|numi|||
|Shottr|||
|Flycut|||
|AltTab|||
|MonitorControl|||
|Postman|||
|Meld|||
|Unarchiver|||
|Pinta|||
|Wireshark|||
|PDFgear|||
|Sourcetree|||
|Hidden bar|||
