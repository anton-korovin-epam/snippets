youtube-dl -c -o "%(title)s-%(id)s.%(ext)s" -f best --write-sub --write-auto-sub --sub-lang en --embed-subs -k $1

