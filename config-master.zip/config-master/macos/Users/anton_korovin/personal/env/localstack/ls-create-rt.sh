Q="rt-external-request rt-request-ready refinement-done monitoring fundamentals textract "
B="rt-extractor rt-external-bucket "

for q in ${Q};
do
    echo "Create QUEUE '$q'"
    laws-sqs-create-queue $q
done

for b in ${B};
do
    echo "Create BUCKET '$b'"
    laws-s3-create-bucket ${b}
done
