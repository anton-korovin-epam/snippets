# How to display dialog and notification
$ osascript -e 'display dialog "Are you sure!?" buttons {"No", "Yes"}'
button returned:No

% osascript -e 'button returned of (display dialog "Are you sure!?" buttons {"No", "Yes"})'
No


% osacscript -e 'display notification "Hello, again" with title "Hello"'
