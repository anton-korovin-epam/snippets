H=$HOME

DIRS_TO_CREATE=".config .local"


for d in $DIRS_TO_CREATE;
do
  echo "Creating $H/$d"
  mkdir -p $H/$d
  r=$?
  if [[ "$r" == "0" ]];
  then
    echo "OK"
  else
    echo "!! FAILED !!"
  fi
done

